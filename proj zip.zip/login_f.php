<?php

include_once("db_connect.php");

session_start();

$username = $_POST['username'];

$_SESSION['username']=$username;

$qStr = "SELECT e_username FROM emp WHERE e_username = '$username';";
$qRes = $db->query($qStr);
$rowCount = $qRes->rowCount();

if($rowCount >= 1)
{
    header('location:admin_profile.php');    
}
else
{
    header('location:user_profile.php');
}
exit;

?>
