<?php
  
?>

<HTML>
	<TITLE> Upload+Parse </TITLE>
<HEAD>
  
<STYLE>
	input[type=submit] {
  	color: black;
  	border-radius: 15px;	
  	cursor: pointer;
  	border: 1.5px solid black;
  	margin-left: 0px;
  	height: 25px;
}

</STYLE>

<BODY>

<h3>Upload an Excel file</h3>

<form method="POST" action="excel_f.php">
  <label for="excel">Select an Excel file:</label>
  <input type="file" name="excel">
  <br><br>
  <input type="submit" value="submit">
</form>

</BODY>

</HEAD>
</HTML>